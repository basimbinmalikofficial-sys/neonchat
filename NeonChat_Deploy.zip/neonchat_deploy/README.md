# NeonChat v2 — Render.com Deployment Guide

## Step 1: GitHub par upload karo

1. GitHub.com par jao → New Repository banao
2. Repository ka naam: `neonchat` rakho
3. Ye saare files upload karo:
   - app.py
   - requirements.txt
   - Procfile
   - templates/ (folder)

## Step 2: Render.com par deploy karo

1. https://render.com par jao
2. Sign Up karo (free) — GitHub se login karo
3. Dashboard mein "New +" click karo
4. "Web Service" select karo
5. Apna GitHub repo (neonchat) connect karo
6. Yeh settings rakho:
   - Name: neonchat
   - Runtime: Python 3
   - Build Command: pip install -r requirements.txt
   - Start Command: gunicorn --worker-class geventwebsocket.gunicorn.workers.GeventWebSocketWorker -w 1 app:app
   - Plan: Free
7. "Create Web Service" click karo
8. 2-3 minute wait karo...

## Step 3: URL milega

Deploy hone ke baad URL milega jaise:
  https://neonchat-xxxx.onrender.com

Ye URL kisi bhi device par, duniya mein kahin bhi kaam karega!

## Test karna
- Device 1: URL kholo, "Ali" se login
- Device 2: Same URL kholo, "Sara" se login
- Dono par real-time chat!

## Note
- Free plan par app 15 min baad sleep ho jata hai
- Pehli baar open karne par 30-60 sec lag sakte hain
- Messages server restart par reset hote hain
