from flask import Flask, render_template, request, session, redirect, url_for
from flask_socketio import SocketIO, emit, join_room, leave_room
from datetime import datetime
import random
import os

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'neonchat_secret_2024')
socketio = SocketIO(app, cors_allowed_origins="*", async_mode='gevent')

# In-memory storage
messages = []       # list of message dicts
online_users = {}   # sid -> {username, color, room}
rooms = ['General', 'Random', 'Tech', 'Gaming']

COLORS = [
    '#FF6B6B', '#4ECDC4', '#45B7D1', '#96CEB4',
    '#FFEAA7', '#DDA0DD', '#98D8C8', '#F7DC6F',
    '#BB8FCE', '#85C1E9', '#F0A500', '#00C896'
]

def get_color():
    return random.choice(COLORS)

# ─── Routes ───────────────────────────────────────────────────────────────────

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        username = request.form.get('username', '').strip()[:20]
        room = request.form.get('room', 'General')
        if username:
            session['username'] = username
            session['color'] = get_color()
            session['room'] = room if room in rooms else 'General'
            return redirect(url_for('chat'))
    return render_template('index.html', rooms=rooms)

@app.route('/chat')
def chat():
    if 'username' not in session:
        return redirect(url_for('index'))
    room = session.get('room', 'General')
    room_msgs = [m for m in messages if m['room'] == room][-50:]
    return render_template('chat.html',
                           username=session['username'],
                           color=session['color'],
                           room=room,
                           rooms=rooms,
                           messages=room_msgs)

@app.route('/switch_room')
def switch_room():
    room = request.args.get('room', 'General')
    if room in rooms:
        session['room'] = room
    return '', 204

@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

# ─── SocketIO Events ──────────────────────────────────────────────────────────

@socketio.on('connect')
def on_connect():
    if 'username' not in session:
        return False
    username = session['username']
    color    = session['color']
    room     = session.get('room', 'General')
    online_users[request.sid] = {'username': username, 'color': color, 'room': room}
    join_room(room)
    # Notify room
    emit('user_joined', {
        'username': username,
        'color': color,
        'room': room,
        'online': [v for v in online_users.values() if v['room'] == room]
    }, to=room)

@socketio.on('disconnect')
def on_disconnect():
    user = online_users.pop(request.sid, None)
    if user:
        emit('user_left', {
            'username': user['username'],
            'color': user['color'],
            'online': [v for v in online_users.values() if v['room'] == user['room']]
        }, to=user['room'])

@socketio.on('send_message')
def on_message(data):
    if 'username' not in session:
        return
    text = data.get('text', '').strip()[:500]
    if not text:
        return
    room = session.get('room', 'General')
    msg = {
        'username': session['username'],
        'color':    session['color'],
        'text':     text,
        'room':     room,
        'time':     datetime.now().strftime('%H:%M')
    }
    messages.append(msg)
    if len(messages) > 500:
        messages.pop(0)
    emit('new_message', msg, to=room)

@socketio.on('typing')
def on_typing(data):
    room = session.get('room', 'General')
    emit('user_typing', {
        'username': session['username'],
        'color':    session['color'],
        'typing':   data.get('typing', False)
    }, to=room, include_self=False)

if __name__ == '__main__':
    socketio.run(app, debug=False, host='0.0.0.0',
                 port=int(os.environ.get('PORT', 5000)))
